# Author: Botao Yu

pos_resolution = 12
max_ts_denominator_power = 6
max_notes_per_bar = 2
tempo_quant = 12
min_tempo = 16
max_tempo = 256
velocity_quant = 4
max_duration = 8
max_bar_num = 256
