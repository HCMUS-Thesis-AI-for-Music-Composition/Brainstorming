export interface ITrackMute {
  shouldPlayTrack(trackId: number): boolean
}
