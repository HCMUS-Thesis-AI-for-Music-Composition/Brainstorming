from transformers import(

  LongformerConfig, LongformerModel,
  LongformerTokenizer,
  LongformerTokenizerFast,
  LongformerModel,
  LongformerForMaskedLM,
  LongformerForQuestionAnswering
)

class MuFormer