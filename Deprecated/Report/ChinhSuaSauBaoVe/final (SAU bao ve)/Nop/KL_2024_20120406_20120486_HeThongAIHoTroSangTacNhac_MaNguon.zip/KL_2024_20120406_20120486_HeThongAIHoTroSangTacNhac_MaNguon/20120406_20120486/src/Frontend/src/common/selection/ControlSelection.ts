export interface ControlSelection {
  fromTick: number
  toTick: number
}
