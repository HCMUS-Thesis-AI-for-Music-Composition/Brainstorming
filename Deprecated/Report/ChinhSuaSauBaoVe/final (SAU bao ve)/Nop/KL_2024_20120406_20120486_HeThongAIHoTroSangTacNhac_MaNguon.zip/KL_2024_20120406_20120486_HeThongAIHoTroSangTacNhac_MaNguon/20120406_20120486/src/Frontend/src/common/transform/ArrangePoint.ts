export interface ArrangePoint {
  tick: number
  trackIndex: number
}
