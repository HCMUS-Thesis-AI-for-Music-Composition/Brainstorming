import Song from "../../common/song"

export interface SongStore {
  song: Song
}
