python3.10 verbalizer_vn.py test
python3.10 format.py
# python verbalizer.py test
# python format.py