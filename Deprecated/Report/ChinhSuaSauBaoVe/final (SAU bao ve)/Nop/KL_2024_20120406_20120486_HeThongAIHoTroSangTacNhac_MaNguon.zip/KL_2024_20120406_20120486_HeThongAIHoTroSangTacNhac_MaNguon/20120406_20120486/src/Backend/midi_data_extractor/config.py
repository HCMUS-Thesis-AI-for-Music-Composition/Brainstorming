attribute_versions_list = {
    'v1': ['I1', 'I2', 'B1', 'TS1', 'T1', 'P1', 'P2', 'P3', 'ST1', 'EM1'],
    'v2': ['I1s1', 'I2s1', 'C1', 'R2', 'S1', 'S2', 'S3', 'B1s1', 'TS1s1', 'K1', 'T1', 'P3', 'P4', 'ST1', 'EM1'],
    'v3': ['I1s2', 'I4', 'C1', 'R1', 'R3', 'S2s1', 'S4', 'B1s1', 'TS1s1', 'K1', 'T1s1', 'P4', 'ST1', 'EM1', 'TM1'],
}
