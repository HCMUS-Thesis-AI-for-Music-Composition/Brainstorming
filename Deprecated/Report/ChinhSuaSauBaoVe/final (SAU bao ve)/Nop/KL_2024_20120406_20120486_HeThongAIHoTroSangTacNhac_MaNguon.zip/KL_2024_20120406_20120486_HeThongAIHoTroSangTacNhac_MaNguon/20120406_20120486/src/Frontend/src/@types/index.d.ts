declare module "*.png"
declare module "*.svg"

interface Window {
  webkitAudioContext: typeof AudioContext
}
