python3 verbalizer.py test
python3 format.py